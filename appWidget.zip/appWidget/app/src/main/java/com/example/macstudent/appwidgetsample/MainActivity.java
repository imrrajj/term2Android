package com.example.macstudent.appwidgetsample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("Raj","a person is trying to run but falling down");
        Log.d("Raj","he is not taking position properly");
    }
}
