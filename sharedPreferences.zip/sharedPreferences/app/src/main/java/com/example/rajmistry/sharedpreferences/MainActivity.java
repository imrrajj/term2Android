package com.example.rajmistry.sharedpreferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    SharedPreferences prefs;

    public  static final String PREFERENCES_NAME = "com.example.rajmistry.sharedpreferences";

    EditText e;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);

        e = (EditText)findViewById(R.id.editText);

    }
    public void saveData(View view) {

        SharedPreferences.Editor prefEditor = prefs.edit();
        String n =e.getText().toString();
        prefEditor.putString("name",n);

        //prefEditor.putString("name","Raj");

        prefEditor.apply();
        Log.d("Raj", "i saved something!!");

        Log.d("Raj", "save button pressed!");
    }

    public void fetchData(View view) {
        Log.d("Raj", "fetch button pressed!");

        String n = prefs.getString("name","-1");

        Log.d("Raj","got something out of database" + n);

    }



}
